package com.example.ProductManagement.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Manager {

	
	@Id
	@Column(length=20)
	@NotBlank
	private String managerId;
	
	@Size(min=7,max=20,message = "password should be between 5 & 20 characters")
	private String password;
	
	
}
