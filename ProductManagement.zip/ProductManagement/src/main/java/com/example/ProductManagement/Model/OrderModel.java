package com.example.ProductManagement.Model;




import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@ToString


public class OrderModel {
	
	private int customerId;
	private int productId;
	private String orderType;
	private int quantity;
	
	
	
	
	

	
	

}
