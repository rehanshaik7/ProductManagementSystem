package com.example.ProductManagement.Exception;

public class ManagerNotFoundException extends Exception {

	

	public ManagerNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}



}
