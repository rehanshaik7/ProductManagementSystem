package com.example.ProductManagement;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.ProductManagement.Controller.CustomerController;
import com.example.ProductManagement.Exception.CustomerNotFoundException;
import com.example.ProductManagement.Model.CustomerInputModel;
import com.example.ProductManagement.Model.CustomerOutputModel;
import com.example.ProductManagement.entity.Customer;
import com.example.ProductManagement.service.CustomerService;

@ExtendWith(MockitoExtension.class)
public class CustomerControllerTests {
	

    @Mock
    private CustomerService customerService;

    @InjectMocks
    private CustomerController customerController;

    @Test
    void testAddCustomer() {
        // Create a mock input model
        CustomerInputModel inputModel = new CustomerInputModel();
        // Set the necessary properties of the input model

        // Create a mock customer object
        Customer customer = new Customer();
        // Set the necessary properties of the customer object

        // Configure the behavior of the mock service
        when(customerService.addCustomer(inputModel)).thenReturn(customer);

        // Call the method under test
        Customer result = customerController.addCustomer(inputModel);

        // Verify that the service addCustomer method was called with the correct argument
        verify(customerService).addCustomer(inputModel);

        // Assert the result
        assertEquals(customer, result);
    }


    @Test
    void testFindAllCustomers() {
        // Create a list of mock customer output models
        List<CustomerOutputModel> customerOutputModels = Arrays.asList(
                new CustomerOutputModel(),
                new CustomerOutputModel()
        );
        

        // Configure the behavior of the mock service
        when(customerService.getCustomers()).thenReturn(customerOutputModels);

        // Call the method under test
        List<CustomerOutputModel> result = customerController.findAllCustomers();

        // Verify that the service getCustomers method was called
        verify(customerService).getCustomers();

        // Assert the result
        assertEquals(customerOutputModels, result);
    }
    @Test
    void testSearchCustomerById() throws CustomerNotFoundException {
        int customerId = 1;
        CustomerOutputModel customerOutputModel = new CustomerOutputModel();
        when(customerService.searchCustomerById(customerId)).thenReturn(customerOutputModel);

        CustomerOutputModel result = customerController.searchCustomerById(customerId);

        verify(customerService).searchCustomerById(customerId);
        assertEquals(customerOutputModel, result);
    }

    
    @Test
    void testUpdateCustomer() throws CustomerNotFoundException {
        int customerId = 1;
        CustomerInputModel customerInputModel = new CustomerInputModel();
        CustomerOutputModel newCustomerOutputModel = new CustomerOutputModel();
        when(customerService.updateCustomer(customerInputModel, customerId)).thenReturn(newCustomerOutputModel);

        CustomerOutputModel result = customerController.updateCustomer(customerInputModel, customerId);

        verify(customerService).updateCustomer(customerInputModel, customerId);
        assertEquals(newCustomerOutputModel, result);
    }

    @Test
    void testDeleteCustomerById() throws CustomerNotFoundException {
        int customerId = 1;

        assertDoesNotThrow(() -> customerController.deleteCustomerById(customerId));

        verify(customerService).removeCustomerById(customerId);
    }
}
