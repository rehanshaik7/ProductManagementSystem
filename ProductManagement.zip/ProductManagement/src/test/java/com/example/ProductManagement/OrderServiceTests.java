package com.example.ProductManagement;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.ProductManagement.Exception.CustomerNotFoundException;
import com.example.ProductManagement.Exception.OrderException;
import com.example.ProductManagement.Exception.ProductNotFoundException;
import com.example.ProductManagement.Model.CustomerOutputModel;
import com.example.ProductManagement.Model.OrderModel;
import com.example.ProductManagement.Model.ProductOutputModel;
import com.example.ProductManagement.entity.Order;
import com.example.ProductManagement.repository.OrderRepository;
import com.example.ProductManagement.service.CustomerService;
import com.example.ProductManagement.service.OrderService;
import com.example.ProductManagement.service.ProductService;


@ExtendWith(MockitoExtension.class)
public class OrderServiceTests {
	    @Mock
	    private ProductService productService;

	    @Mock
	    private CustomerService customerService;

	    @Mock
	    private OrderRepository orderRepository;

	    @InjectMocks
	    private OrderService orderService;

	    @Test
	    void testCreateOrder_SaleOrder_Success() throws ProductNotFoundException, OrderException, CustomerNotFoundException {
	        // Mock data
	        int productId = 1;
	        int customerId = 1;
	        int quantity = 5;
	        String orderType = "sale";
	        double price = 10.0;
	        int stock = 10;

	        ProductOutputModel product = new ProductOutputModel();
	        product.setId(productId);
	        product.setPrice(price);
	        product.setStock(stock);

	        CustomerOutputModel customer = new CustomerOutputModel();
	        customer.setId(customerId);

	        OrderModel orderModel = new OrderModel();
	        orderModel.setProductId(productId);
	        orderModel.setCustomerId(customerId);
	        orderModel.setQuantity(quantity);
	        orderModel.setOrderType(orderType);

	        // Configure mock behavior
	        when(productService.viewProductById(productId)).thenReturn(product);
	        when(customerService.searchCustomerById(customerId)).thenReturn(customer);

	        // Invoke the method
	        Order result = orderService.createOrder(orderModel);

	        // Verify interactions
	        verify(productService).viewProductById(productId);
	        verify(customerService).searchCustomerById(customerId);
	        verify(productService).updateStock(productId, stock - quantity);
	        verify(orderRepository).save(any(Order.class));

	        // Assert the result
	       assertNotNull(result);
	        assertEquals(orderType, result.getOrderType());
	        assertEquals(quantity, result.getQuantity());
	        assertEquals(price * quantity, result.getInvoiceAmount());
	        assertEquals(stock - quantity, result.getProduct().getStock());
	        assertEquals(customerId, result.getCustomer().getId());
	        assertEquals(productId, result.getProduct().getId());
	    }

	    @Test
	    void testCreateOrder_PurchaseOrder_Success() throws ProductNotFoundException, OrderException, CustomerNotFoundException {
	        // Mock data
	        int productId = 1;
	        int customerId = 1;
	        int quantity = 5;
	        String orderType = "purchase";
	        double price = 10.0;
	        int stock = 10;

	        ProductOutputModel product = new ProductOutputModel();
	        product.setId(productId);
	        product.setPrice(price);
	        product.setStock(stock);

	        CustomerOutputModel customer = new CustomerOutputModel();
	        customer.setId(customerId);

	        OrderModel orderModel = new OrderModel();
	        orderModel.setProductId(productId);
	        orderModel.setCustomerId(customerId);
	        orderModel.setQuantity(quantity);
	        orderModel.setOrderType(orderType);

	        // Configure mock behavior
	        when(productService.viewProductById(productId)).thenReturn(product);
	        when(customerService.searchCustomerById(customerId)).thenReturn(customer);

	        // Invoke the method
	        Order result = orderService.createOrder(orderModel);

	        // Verify interactions
	        verify(productService).viewProductById(productId);
	        verify(customerService).searchCustomerById(customerId);
	        verify(productService).updateStock(productId, stock + quantity);
	        verify(orderRepository).save(any(Order.class));

	        // Assert the result
	        assertNotNull(result);
	        assertEquals(orderType, result.getOrderType());
	        assertEquals(quantity, result.getQuantity());
	        assertEquals(price * quantity, result.getInvoiceAmount());
	        assertEquals(stock + quantity, result.getProduct().getStock());
	        assertEquals(customerId, result.getCustomer().getId());
	        assertEquals(productId, result.getProduct().getId());
	    }
	
	
	}

