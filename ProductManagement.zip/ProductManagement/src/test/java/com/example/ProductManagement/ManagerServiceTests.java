package com.example.ProductManagement;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.ProductManagement.Exception.ManagerNotFoundException;
import com.example.ProductManagement.entity.Manager;
import com.example.ProductManagement.repository.ManagerRepository;
import com.example.ProductManagement.service.ManagerService;


@ExtendWith(MockitoExtension.class)
public class ManagerServiceTests {

	 @Mock
	    private ManagerRepository managerRepository;

	    @InjectMocks
	    private ManagerService managerService;

	    @Captor
	    private ArgumentCaptor<Manager> managerCaptor;

	    @Test
	    void testRegisterManager() {
	        // Create a sample Manager object
	        Manager manager = new Manager();
	        manager.setManagerId("John");
	        manager.setPassword("12345666789");

	        // Configure the behavior of the mock repository
	        when(managerRepository.save(any(Manager.class))).thenReturn(manager);

	        // Call the method under test
	        Manager savedManager = managerService.registerManager(manager);

	        // Verify that the repository save method was called with the correct Manager object
	        verify(managerRepository).save(managerCaptor.capture());
	        Manager capturedManager = managerCaptor.getValue();
	        assertEquals(manager.getManagerId(), capturedManager.getManagerId());
	        assertEquals(manager.getPassword(), capturedManager.getPassword());

	        // Verify that the returned Manager object is the same as the one returned by the mock repository
	        assertEquals(manager, savedManager);
	    }
	    
	    @Test
	    void testLoginManager_ValidCredentials() throws ManagerNotFoundException {
	        // Create a sample Manager object
	        String managerId = "john123";
	        String password = "password";
	        Manager manager = new Manager();
	        manager.setManagerId(managerId);
	        manager.setPassword(password);

	        // Configure the behavior of the mock repository
	        when(managerRepository.findById(managerId)).thenReturn(Optional.of(manager));

	        // Call the method under test
	        Manager loggedManager = managerService.loginManager(managerId, password);

	        // Verify that the repository findById method was called with the correct managerId
	        verify(managerRepository).findById(managerId);

	        // Verify that the returned Manager object is the same as the one from the mock repository
	        assertEquals(manager, loggedManager);
	    }

	    @Test
	    void testLoginManager_InvalidManagerId() {
	        // Create a sample Manager object
	        String managerId = "john123";
	        String password = "password";
	        
	        // Configure the behavior of the mock repository
	        when(managerRepository.findById(managerId)).thenReturn(Optional.empty());

	        // Call the method under test and assert that it throws ManagerNotFoundException
	        assertThrows(ManagerNotFoundException.class, () -> managerService.loginManager(managerId, password));

	        // Verify that the repository findById method was called with the correct managerId
	        verify(managerRepository).findById(managerId);
	    }

	    @Test
	    void testLoginManager_InvalidPassword() {
	        // Create a sample Manager object
	        String managerId = "john123";
	        String password = "password";
	        Manager manager = new Manager();
	        manager.setManagerId(managerId);
	        manager.setPassword("wrongpassword");
	        
	        // Configure the behavior of the mock repository
	        when(managerRepository.findById(managerId)).thenReturn(Optional.of(manager));

	        // Call the method under test and assert that it throws ManagerNotFoundException
	        assertThrows(ManagerNotFoundException.class, () -> managerService.loginManager(managerId, password));

	        // Verify that the repository findById method was called with the correct managerId
	        verify(managerRepository).findById(managerId);
	    }
	    
	}
	





