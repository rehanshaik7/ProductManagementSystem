package com.example.ProductManagement;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.ProductManagement.Controller.ManagerController;
import com.example.ProductManagement.Exception.ManagerNotFoundException;
import com.example.ProductManagement.entity.Manager;
import com.example.ProductManagement.service.ManagerService;

@ExtendWith(MockitoExtension.class)
public class ManagerControllerTests {

	   @Mock
	    private ManagerService managerService;

	    @InjectMocks
	    private ManagerController managerController;
	    
	    @Test
	    void testRegisterManager() {
	        // Create a sample Manager object
	        Manager manager = new Manager();
	        manager.setManagerId("John");
	        manager.setPassword("john@example.com");
	        // Set other properties as needed
	        
	        // Configure the behavior of the mock service
	        when(managerService.registerManager(manager)).thenReturn(manager);

	        // Call the method under test
	        Manager registeredManager = managerController.registerManager(manager);

	        // Verify that the service registerManager method was called with the correct manager object
	        verify(managerService).registerManager(manager);

	        // Verify that the returned Manager object is the same as the one from the mock service
	        assertEquals(manager, registeredManager);
	    }

	    @Test
	    void testLoginManager_ValidCredentials() throws ManagerNotFoundException {
	        // Define the input parameters
	        String managerId = "123";
	        String password = "password";

	        // Create a sample Manager object
	        Manager manager = new Manager();
	        manager.setManagerId(managerId);
	        manager.setPassword(password);

	        // Configure the behavior of the mock service
	        when(managerService.loginManager(managerId, password)).thenReturn(manager);

	        // Call the method under test
	        Manager loggedInManager = managerController.loginManager(managerId, password);

	        // Verify that the service loginManager method was called with the correct parameters
	        verify(managerService).loginManager(managerId, password);

	        // Verify that the returned Manager object is the same as the one from the mock service
	        assertEquals(manager, loggedInManager);
	    }

	    @Test
	    void testLoginManager_InvalidCredentials() throws ManagerNotFoundException {
	        // Define the input parameters
	        String managerId = "123";
	        String password = "password";
	        

	        // Configure the behavior of the mock service to throw an exception
	        when(managerService.loginManager(managerId, password)).thenThrow(ManagerNotFoundException.class);

	        // Call the method under test and assert that it throws the expected exception
	        assertThrows(ManagerNotFoundException.class, () -> managerController.loginManager(managerId, password));

	        // Verify that the service loginManager method was called with the correct parameters
	        verify(managerService).loginManager(managerId, password);
	    }
}
