package com.example.ProductManagement;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.ProductManagement.Controller.ProductController;
import com.example.ProductManagement.Exception.ProductNotFoundException;
import com.example.ProductManagement.Model.ProductInputModel;
import com.example.ProductManagement.Model.ProductOutputModel;
import com.example.ProductManagement.entity.Product;
import com.example.ProductManagement.service.ProductService;

@ExtendWith(MockitoExtension.class)
public class ProductControllerTests {

	
	    @Mock
	    private ProductService productService;

	    @InjectMocks
	    private ProductController productController;

	    @Test
	    void testAddProduct_Success() {
	        // Define the input parameters
	        ProductInputModel productInputModel = new ProductInputModel();
	        // Set the properties of the productInputModel

	        // Create a sample Product object
	        Product product = new Product();
	        // Set the properties of the product

	        // Configure the behavior of the mock service
	        when(productService.addProduct(productInputModel)).thenReturn(product);

	        // Call the method under test
	        ResponseEntity<Product> responseEntity = productController.addProduct(productInputModel);

	        // Verify that the service addProduct method was called with the correct parameters
	        verify(productService).addProduct(productInputModel);

	        // Verify that the response status is OK (200)
	        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());

	        // Verify that the returned Product object is the same as the one from the mock service
	        assertEquals(product, responseEntity.getBody());
	    }

	    @Test
	    void testAddProduct_ProductExists() {
	        // Define the input parameters
	        ProductInputModel productInputModel = new ProductInputModel();
	        // Set the properties of the productInputModel

	        // Configure the behavior of the mock service to throw an IllegalArgumentException
	        when(productService.addProduct(productInputModel)).thenThrow(IllegalArgumentException.class);

	        // Call the method under test
	        ResponseEntity<Product> responseEntity = productController.addProduct(productInputModel);

	        // Verify that the service addProduct method was called with the correct parameters
	        verify(productService).addProduct(productInputModel);

	        // Verify that the response status is BAD_REQUEST (400)
	        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());

	        // Verify that the error message in the response body is correct
	        String expectedErrorMessage = "Product with the same name already exists";
	        assertEquals(expectedErrorMessage, responseEntity.getBody().getName());
	    }
	    
	    @Test
	    void testFindAllProducts() {
	        // Create a sample list of ProductOutputModel objects
	        List<ProductOutputModel> productOutputModels = Arrays.asList(
	                new ProductOutputModel(),
	                new ProductOutputModel(),
	                new ProductOutputModel()
	        );

	        // Configure the behavior of the mock service
	        when(productService.getProducts()).thenReturn(productOutputModels);

	        // Call the method under test
	        List<ProductOutputModel> result = productController.findAllProducts();

	        // Verify that the service getProducts method was called
	        verify(productService).getProducts();

	        // Verify the size of the returned list
	        assertEquals(productOutputModels.size(), result.size());

	        // Verify that the returned list is the same as the sample list
	        assertSame(productOutputModels, result);
	    }
	    @Test
	    void testSearchProductById() throws ProductNotFoundException {
	        // Create a sample ProductOutputModel object
	        ProductOutputModel productOutputModel = new ProductOutputModel();

	        // Configure the behavior of the mock service
	        when(productService.viewProductById(123)).thenReturn(productOutputModel);

	        // Call the method under test
	        ProductOutputModel result = productController.searchProductById(123);

	        // Verify that the service viewProductById method was called with the correct argument
	        verify(productService).viewProductById(123);

	        // Verify that the returned ProductOutputModel is the same as the sample object
	        assertSame(productOutputModel, result);
	    }

	    @Test
	    void testSearchProductById_ProductNotFoundException() throws ProductNotFoundException {
	        // Configure the behavior of the mock service to throw ProductNotFoundException
	        when(productService.viewProductById(123)).thenThrow(new ProductNotFoundException("Product not found"));

	        // Call the method under test and assert that it throws ProductNotFoundException
	        assertThrows(ProductNotFoundException.class, () -> productController.searchProductById(123));

	        // Verify that the service viewProductById method was called with the correct argument
	        verify(productService).viewProductById(123);
	    }
	    @Test
	    void testUpdateProduct() throws ProductNotFoundException {
	        // Create a sample ProductInputModel object
	        ProductInputModel productInputModel = new ProductInputModel();

	        // Create a sample ProductOutputModel object
	        ProductOutputModel updatedProduct = new ProductOutputModel();

	        // Configure the behavior of the mock service
	        when(productService.updateProduct(productInputModel, 123)).thenReturn(updatedProduct);

	        // Call the method under test
	        ProductOutputModel result = productController.updateProduct(productInputModel, 123);

	        // Verify that the service updateProduct method was called with the correct arguments
	        verify(productService).updateProduct(productInputModel, 123);

	        // Verify that the returned ProductOutputModel is the same as the sample object
	        assertSame(updatedProduct, result);
	    }

	    @Test
	    void testUpdateProduct_ProductNotFoundException() throws ProductNotFoundException {
	        // Create a sample ProductInputModel object
	        ProductInputModel productInputModel = new ProductInputModel();

	        // Configure the behavior of the mock service to throw ProductNotFoundException
	        when(productService.updateProduct(productInputModel, 123))
	                .thenThrow(new ProductNotFoundException("Product not found"));

	        // Call the method under test and assert that it throws ProductNotFoundException
	        assertThrows(ProductNotFoundException.class, () -> productController.updateProduct(productInputModel, 123));

	        // Verify that the service updateProduct method was called with the correct arguments
	        verify(productService).updateProduct(productInputModel, 123);
	    }
	    
	    @Test
	    void testDeleteProductById() throws ProductNotFoundException {
	        // Call the method under test
	        productController.deleteProductById(123);

	        // Verify that the service removeProductById method was called with the correct argument
	        verify(productService).removeproductById(123);
	    }

	    @Test
	    void testDeleteProductById_ProductNotFoundException() throws ProductNotFoundException {
	        // Configure the behavior of the mock service to throw ProductNotFoundException
	        doThrow(new ProductNotFoundException("Product not found")).when(productService).removeproductById(123);

	        // Call the method under test and assert that it throws ProductNotFoundException
	        assertThrows(ProductNotFoundException.class, () -> productController.deleteProductById(123));

	        // Verify that the service removeProductById method was called with the correct argument
	        verify(productService).removeproductById(123);
	    }
}
