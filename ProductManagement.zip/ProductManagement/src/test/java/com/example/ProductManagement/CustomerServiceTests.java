package com.example.ProductManagement;



import org.junit.jupiter.api.BeforeEach;


import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

//import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
//import static org.junit.Assert.assertEquals;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import com.example.ProductManagement.Exception.CustomerNotFoundException;
import com.example.ProductManagement.Model.CustomerInputModel;
import com.example.ProductManagement.Model.CustomerOutputModel;
import com.example.ProductManagement.Model.ProductInputModel;
import com.example.ProductManagement.entity.Customer;
import com.example.ProductManagement.entity.Product;
import com.example.ProductManagement.repository.CustomerRepository;
import com.example.ProductManagement.service.CustomerService;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

public class CustomerServiceTests {

	@Mock
	private CustomerRepository customerRepository;

	@InjectMocks
	private CustomerService customerService;

	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testAddCustomer() {
		CustomerInputModel inputCustomer = new CustomerInputModel();
		inputCustomer.setFirstName("John");
		inputCustomer.setLastName("Doe");
		inputCustomer.setPhoneNumber("1234567890");
		inputCustomer.setCity("New York");

		Customer savedCustomer = new Customer();
		savedCustomer.setId(42);
		when(customerRepository.save(any(Customer.class))).thenReturn(savedCustomer);

		Customer addedCustomer = customerService.addCustomer(inputCustomer);

		
		verify(customerRepository, times(1)).save(any(Customer.class));

		assertSame(savedCustomer, addedCustomer);
		
	}
	
	 @Test
	    void testSearchCustomerById() throws CustomerNotFoundException {
	        // Arrange
	        int customerId = 1;
	        Customer customer = new Customer();
	        customer.setId(customerId);
	        customer.setFirstName("John");
	        customer.setLastName("Doe");
	        customer.setPhoneNumber("1234567890");
	        customer.setCity("Sample City");

	        when(customerRepository.findById(customerId)).thenReturn(java.util.Optional.of(customer));

	        // Act
	        CustomerOutputModel result = customerService.searchCustomerById(customerId);

	        // Assert
	        verify(customerRepository, times(1)).findById(customerId);
	        assertNotNull(result);
	       assertEquals(customerId, result.getId());
	        assertSame("John", result.getFirstName());
	        assertSame("Doe", result.getLastName());
	       assertSame("1234567890", result.getPhoneNumber());
	        assertSame("Sample City", result.getCity());
	    }
	 
	 @Test
	    void testGetCustomers() {
	        // Arrange
	        Customer customer1 = new Customer();
	        customer1.setId(1);
	        customer1.setFirstName("John");
	        customer1.setLastName("Doe");
	        customer1.setPhoneNumber("1234567890");
	        customer1.setCity("Sample City");

	        Customer customer2 = new Customer();
	        customer2.setId(2);
	        customer2.setFirstName("Jane");
	        customer2.setLastName("Smith");
	        customer2.setPhoneNumber("9876543210");
	        customer2.setCity("Another City");

	        List<Customer> customerList = new ArrayList<>();
	        customerList.add(customer1);
	        customerList.add(customer2);

	        when(customerRepository.findAll()).thenReturn(customerList);

	        // Act
	        List<CustomerOutputModel> result = customerService.getCustomers();

	        // Assert
	        verify(customerRepository, times(1)).findAll();
	        assertEquals(2, result.size());

	        CustomerOutputModel resultCustomer1 = result.get(0);
	        assertEquals(1, resultCustomer1.getId());
	        assertSame("John", resultCustomer1.getFirstName());
	        assertSame("Doe", resultCustomer1.getLastName());
	      assertSame("1234567890", resultCustomer1.getPhoneNumber());
	        assertSame("Sample City", resultCustomer1.getCity());

	        CustomerOutputModel resultCustomer2 = result.get(1);
	      assertEquals(2, resultCustomer2.getId());
	     assertSame("Jane", resultCustomer2.getFirstName());
	     assertSame("Smith", resultCustomer2.getLastName());
	        assertSame("9876543210", resultCustomer2.getPhoneNumber());
	       assertSame("Another City", resultCustomer2.getCity());
	    }
	 
	 @Test
	    void testRemoveCustomerById_ValidId() throws CustomerNotFoundException {
	        // Arrange
	        int customerId = 1;
	        Customer customer = new Customer();
	        customer.setId(customerId);
	        customer.setFirstName("John");
	        customer.setLastName("Doe");
	        customer.setPhoneNumber("1234567890");
	        customer.setCity("Sample City");

	        when(customerRepository.findById(customerId)).thenReturn(java.util.Optional.of(customer));

	        // Act and Assert
	        assertDoesNotThrow(() -> {
	            customerService.removeCustomerById(customerId);
	        });

	        verify(customerRepository, times(1)).findById(customerId);
	        verify(customerRepository, times(1)).deleteById(customerId);
	    }

	    @Test
	    void testRemoveCustomerById_CustomerNotFound() {
	        // Arrange
	        int customerId = 1;

	        when(customerRepository.findById(customerId)).thenReturn(java.util.Optional.empty());

	        // Act and Assert
	      assertThrows(CustomerNotFoundException.class, () -> {
	            customerService.removeCustomerById(customerId);
	        });

	        verify(customerRepository, times(1)).findById(customerId);
	        verify(customerRepository, never()).deleteById(Mockito.anyInt());
	    }
	    
	    @Test
	    void testUpdateCustomer_ValidId() throws CustomerNotFoundException {
	        // Arrange
	        int customerId = 1;
	        CustomerInputModel customerInputModel = new CustomerInputModel();
	        customerInputModel.setFirstName("John");
	        customerInputModel.setLastName("Doe");
	        customerInputModel.setPhoneNumber("1234567890");
	        customerInputModel.setCity("Sample City");

	        Customer existingCustomer = new Customer();
	        existingCustomer.setId(customerId);
	        existingCustomer.setFirstName("OldFirstName");
	        existingCustomer.setLastName("OldLastName");
	        existingCustomer.setPhoneNumber("OldPhoneNumber");
	        existingCustomer.setCity("OldCity");

	        when(customerRepository.getReferenceById(customerId)).thenReturn(existingCustomer);
	        when(customerRepository.save(existingCustomer)).thenReturn(existingCustomer);

	        // Act
	        CustomerOutputModel result = customerService.updateCustomer(customerInputModel, customerId);

	        // Assert
	        verify(customerRepository, times(1)).getReferenceById(customerId);
	        verify(customerRepository, times(1)).save(existingCustomer);

	        assertEquals(customerId, result.getId());
	        assertSame(customerInputModel.getFirstName(), result.getFirstName());
	       assertSame(customerInputModel.getLastName(), result.getLastName());
	       assertSame(customerInputModel.getPhoneNumber(), result.getPhoneNumber());
	       assertSame(customerInputModel.getCity(), result.getCity());
	    }
	    

	    @Test
	    void testUpdateCustomer_CustomerNotFound() {
	        // Arrange
	        int customerId = 1;
	        CustomerInputModel customerInputModel = new CustomerInputModel();
	        customerInputModel.setFirstName("John");
	        customerInputModel.setLastName("Doe");
	        customerInputModel.setPhoneNumber("1234567890");
	        customerInputModel.setCity("Sample City");

	        when(customerRepository.getReferenceById(customerId)).thenReturn(null);

	        // Act and Assert
	      assertThrows(CustomerNotFoundException.class, () -> {
	            customerService.updateCustomer(customerInputModel, customerId);
	        });

	        verify(customerRepository, times(1)).getReferenceById(customerId);
	        verify(customerRepository, never()).save(Mockito.any(Customer.class));
	    }
	
}
