package com.example.ProductManagement;


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.ProductManagement.Controller.OrderController;
import com.example.ProductManagement.Exception.CustomerNotFoundException;
import com.example.ProductManagement.Exception.OrderException;
import com.example.ProductManagement.Exception.ProductNotFoundException;
import com.example.ProductManagement.Model.OrderModel;
import com.example.ProductManagement.Model.OrderOutputModel;
import com.example.ProductManagement.entity.Order;
import com.example.ProductManagement.service.OrderService;

@ExtendWith(MockitoExtension.class)
public class OrderControllerTests {

	@Mock
    private OrderService orderService;

    @InjectMocks
    private OrderController orderController;

    @Test
    void testCreateOrder() throws ProductNotFoundException, OrderException, CustomerNotFoundException {
        OrderModel orderModel = new OrderModel();
        Order order = new Order();
        when(orderService.createOrder(orderModel)).thenReturn(order);

        Order result = orderController.createOrder(orderModel);

        verify(orderService).createOrder(orderModel);
        assertEquals(order, result);
    }
    @Test
    void testGetAllOrders() {
        List<OrderOutputModel> expectedOrders = new ArrayList<>();
        when(orderService.getOrders()).thenReturn(expectedOrders);

        List<OrderOutputModel> result = orderController.getALlOrders();

        verify(orderService).getOrders();
        assertEquals(expectedOrders, result);
    }

    @Test
    void testSearchById() throws OrderException {
        int orderId = 1;
        OrderOutputModel expectedOrder = new OrderOutputModel();
        when(orderService.searchById(orderId)).thenReturn(expectedOrder);

        OrderOutputModel result = orderController.searchById(orderId);

        verify(orderService).searchById(orderId);
        assertEquals(expectedOrder, result);
    }
}
